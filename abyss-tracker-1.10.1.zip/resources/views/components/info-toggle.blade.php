<img
    src="https://img.icons8.com/small/24/{{App\Http\Controllers\ThemeController::getThemedIconColor()}}/info.png"
{{--    style="width: 16px; height: 16px;"--}}
    class="tinyicon"
    data-toggle="tooltip"
    title="{{$slot}}">
