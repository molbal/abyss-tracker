<?php
    return [
        'new-question' => 'Dear :Name,

<a href="showinfo:1377//:askercharid">:Askercharname</a> has just asked a question on your <a href="showinfo::shipid">:Shipname</a> fit called :fit.

To view the question please visit <url=:url/>:url</url> and click the Questions tab.

Fly safe,
The Abyss Accountant on behalf of <a href="showinfo:1377//93940047">Veetor Nara</a>
<url=https://abyss.eve-nt.uk/>Abyss Tracker</url>

<font size="10" color="#b3ffffff">Ps.: Please do not reply directly to this mail, as it is not checked regularly.</font>',

        'new-answer' => 'Dear :Name,

<a href="showinfo:1377//:answercharid">:Answercharname</a> has just answered a question you asked on a <a href="showinfo::shipid">:Shipname</a> fit called :fit.

To view the answer please visit <url=:url/>:url</url> and click the Questions tab.

Fly safe,
The Abyss Accountant on behalf of <a href="showinfo:1377//93940047">Veetor Nara</a>
<url=https://abyss.eve-nt.uk/>Abyss Tracker</url>

<font size="10" color="#b3ffffff">Ps.: Please do not reply directly to this mail, as it is not checked regularly.</font>'
    ];
