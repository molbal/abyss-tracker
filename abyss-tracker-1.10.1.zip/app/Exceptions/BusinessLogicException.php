<?php


	namespace App\Exceptions;


	class BusinessLogicException extends  \Exception {

	}
