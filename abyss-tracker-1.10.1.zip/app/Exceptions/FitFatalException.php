<?php


	namespace App\Exceptions;


	class FitFatalException extends \Exception {

	}
