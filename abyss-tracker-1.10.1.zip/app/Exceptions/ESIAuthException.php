<?php


	namespace App\Exceptions;


	class ESIAuthException extends \Exception {

	}
