<?php


	namespace App\Http\Controllers\EFT\Exceptions;


	class NotAnItemException extends \Exception {

	}
