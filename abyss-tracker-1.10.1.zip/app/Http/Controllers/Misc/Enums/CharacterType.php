<?php


	namespace App\Http\Controllers\Misc\Enums;


	class CharacterType {
        public const ALT = 'alt';
        public const MAIN = 'main';
        public const SINGLE = 'single';
	}
