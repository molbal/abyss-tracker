<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Echarts\Chart;

class SurvivalLevelChart extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
