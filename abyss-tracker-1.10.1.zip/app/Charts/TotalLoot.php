<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Echarts\Chart;

class TotalLoot extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
