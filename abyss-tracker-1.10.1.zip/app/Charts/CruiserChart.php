<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Echarts\Chart;

class CruiserChart extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
