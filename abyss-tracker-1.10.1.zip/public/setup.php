<?php

    echo `php artisan key:generate`;
