<?php


	namespace App\Tracker\DTOs;


	class BookmarkLine {
        public $timeSeconds;
        public $timeFormatted;
        public $label;
        public $timeSecondsNext;
	}
