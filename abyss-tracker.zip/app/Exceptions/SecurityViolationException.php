<?php


	namespace App\Exceptions;


	class SecurityViolationException extends \Exception {

	}
