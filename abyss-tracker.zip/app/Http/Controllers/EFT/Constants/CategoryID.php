<?php


	namespace App\Http\Controllers\EFT\Constants;


	class CategoryID {
        const CHARGE_CATEGORY_ID = 8;
        const DRONE_CATEGORY_ID = 18;
	}
