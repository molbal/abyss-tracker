<?php


	namespace App\Http\Controllers\EFT\Constants;


	class DogmaAttribute {
        const IS_BOOSTER = 1087;
        const IS_IMPLANT = 311;
        const DRONE_BANDWIDTH_AVAILABLE = 1271;
        const DRONE_BANDWIDTH_USED = 1272;
	}
