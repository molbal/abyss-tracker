<?php


	namespace App\Http\Controllers\EFT\Constants;


	class DogmaEffect {
        const IS_HIGH_SLOT = 11;
        const IS_MID_SLOT = 13;
        const IS_LOW_SLOT = 12;
        const IS_RIG_SLOT = 2663;
	}
