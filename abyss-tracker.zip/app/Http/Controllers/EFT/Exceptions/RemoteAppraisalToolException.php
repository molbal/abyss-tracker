<?php


	namespace App\Http\Controllers\EFT\Exceptions;


	class RemoteAppraisalToolException extends \Exception {

	}
