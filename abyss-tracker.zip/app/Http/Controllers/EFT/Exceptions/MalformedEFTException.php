<?php


	namespace App\Http\Controllers\EFT\Exceptions;


	class MalformedEFTException  extends \Exception {

	}
