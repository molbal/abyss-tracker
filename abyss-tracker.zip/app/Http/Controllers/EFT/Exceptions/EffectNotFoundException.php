<?php


	namespace App\Http\Controllers\EFT\Exceptions;


	class EffectNotFoundException extends  \Exception {

	}
