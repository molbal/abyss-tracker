<?php


	namespace App\Http\Controllers\EFT\Exceptions;


	class AttributeNotFoundException extends  \Exception {

	}
