<?php


	namespace App\Http\Controllers\Misc\Enums;


	class ShipHullSize {
        public const FRIGATE = 'frigate';
        public const DESTROYER = 'destroyer';
        public const CRUISER = 'cruiser';
	}
