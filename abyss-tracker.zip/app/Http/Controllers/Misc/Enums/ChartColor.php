<?php


	namespace App\Http\Controllers\Misc\Enums;


	class ChartColor {
        public const RED = 'red';
        public const GREEN = 'green';
        public const BLUE = 'blue';
        public const GRAY = 'gray';
	}
