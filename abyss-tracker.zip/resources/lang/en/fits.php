<?php
    return [
        'records-notice' => "The Abyss Tracker keeps fit history since :date - earlier history entries are not available.",
        'order-by' => [
            'submitted' => 'upload time',
            'runs_count' => 'popularity',
            'fits' => [
                'price' => 'fit price',
                ]
            ]
    ];
