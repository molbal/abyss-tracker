<?php
    return [

        "TagAfterburner"  => "propulsion",
        "TagArmorActive"  => "defense",
        "TagDroneCentric"  => "offense",
        "TagEnergyWeapons"  => "offense",
        "TagHybridWeapons"  => "offense",
        "TagMicrowarpdrive"  => "propulsion",
        "TagMissileWeapons"  => "offense",
        "TagPrecursorWeapons"  => "offense",
        "TagProjectileWeapons"  => "offense",
        "TagShieldActive"  => "defense",
        "TagShieldPassive"  => "defense",
        "TagStrongCapacitor"  => "defense",
        "TagVideo" => "misc"
    ];

