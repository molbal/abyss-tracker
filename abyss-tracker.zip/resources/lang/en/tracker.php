<?php

    return [
      "stopwatch" => [
          "note" => "Your location will be queried only when you visit the <strong>Add new Abyss run</strong> page until you submit the details or 1 hour passes before you loaded the page. Your location is only saved temporarily while the stopwatch is running. It is never used for anything else or displayed anywhere. After the stopwatch ends all location info is immediately deleted."
      ]
    ];
