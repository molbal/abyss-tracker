<?php

return [

    'single' => 'you do not have any alts or mains connected to :Name in the Abyss Tracker yet.',
    'main' => ':Name already has alts connected. :Name may connect other alts, but cannot have a main.',
    'alt' => ':Name already has a main connected. Your main character may have additional alts, but not :Name.',

];
