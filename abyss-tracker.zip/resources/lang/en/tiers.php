<?php
    return [
        "0"  => "Tranquil",
        "1"  => "Calm",
        "2"  => "Agitated",
        "3"  => "Fierce",
        "4"  => "Raging",
        "5"  => "Chaotic",
        "6"  => "Cataclysmic"

    ];
