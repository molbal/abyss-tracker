<img class="{{$class}}" src="https://img.icons8.com/{{$iconset ?? "small"}}/32/{{App\Http\Controllers\ThemeController::getThemedIconColor()}}/{{$icon}}.png">
