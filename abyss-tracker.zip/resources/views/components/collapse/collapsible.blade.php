<div class="collapse {{$show ? "show" : ""}} {{$class ?? ""}}" id="{{$id ?? ""}}">{{$slot}}</div>
