<td>@component("components.resist", ['bg' => '#345662', 'fg' => '#2685c6','resist' => $resists->em])@endcomponent</td>
<td>@component("components.resist", ['bg' => '#534143', 'fg' => '#c62626','resist' => $resists->therm])@endcomponent</td>
<td>@component("components.resist", ['bg' => '#4a5a5d', 'fg' => '#a3a3a3','resist' => $resists->kin])@endcomponent</td>
<td>@component("components.resist", ['bg' => '#515343', 'fg' => '#c68526','resist' => $resists->exp])@endcomponent</td>
