<div class="text-right">
@if($value > 0)
    <span>{{round($value)}}</span>&nbsp;<span class="text-small bringupper">ehp/s</span>
@else
    <span class="text-small bringupper" style="margin-right: 10px">-</span>

@endif
</div>
