<?php return array (
  'new-fit-wizard' => 'App\\Http\\Livewire\\NewFitWizard',
);